<?php

/*

Plugin Name: Solosignal for Onesignal and WooCommerce

Plugin URI: https://durabyte.org/

Description: This plugin helps you connect WooCommerce activities with Onesignal e.g. new orders, order status, etc.

Version: 1.0

Author: Kayode Ojo

Author URI: https://durabyte.org/

License: GPLv2 or later

Text Domain: solosignal

*/


// Test to see if WooCommerce is active (including network activated).
$plugin_path = trailingslashit( WP_PLUGIN_DIR ) . 'woocommerce/woocommerce.php';

if (
    in_array( $plugin_path, wp_get_active_and_valid_plugins() )
    || in_array( $plugin_path, wp_get_active_network_plugins() )
) {
    // Custom code here. WooCommerce is active, however it has not 
    // necessarily initialized (when that is important, consider
    // using the `woocommerce_init` action).
}


function sendMessage($title, $message, $data, $players){


    $getoptions = get_option('solosignal_options');
    $getAppID = (isset($getoptions['onesignal_app_id'])) ? $getoptions['onesignal_app_id'] : '';
    $getApiKey = (isset($getoptions['onesignal_api_key'])) ? $getoptions['onesignal_api_key'] : '';

    $content = array(
        "en" => $message
    );
    $headings = array(
        "en" => $title
    );
    $fields = array(
        'app_id' => $getAppID,
        'include_player_ids' => $players,
        'data' => ["data" => $data],
        'large_icon' =>"ic_launcher_round.png",
        'contents' => $content,
        'headings' => $headings,
    );

    $fields = json_encode($fields);
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, "https://onesignal.com/api/v1/notifications");
    curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json; charset=utf-8',
                                               'Authorization: Basic '.$getApiKey));
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
    curl_setopt($ch, CURLOPT_HEADER, FALSE);
    curl_setopt($ch, CURLOPT_POST, TRUE);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $fields);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);    

    $response = curl_exec($ch);
    curl_close($ch);

    return $response;
}

function myorder_pending($order_id) {
    //$order = wc_get_order($order_id);
    $order_meta = get_post_meta($order_id);
    if(isset($order_meta['player_id']) && isset($order_meta['player_id'][0])){
        sendMessage("Order status changed", "Order #" . $order_id . " is marked pending", ['order_id' => $order_id], [$order_meta['player_id'][0]]);
    }
}
function myorder_failed($order_id) {
    $order_meta = get_post_meta($order_id);
    if(isset($order_meta['player_id']) && isset($order_meta['player_id'][0])){
        sendMessage("Order status changed", "Order #" . $order_id . " is marked failed", ['order_id' => $order_id], [$order_meta['player_id'][0]]);
    }
}
function myorder_hold($order_id) {
    $order_meta = get_post_meta($order_id);
    if(isset($order_meta['player_id']) && isset($order_meta['player_id'][0])){
        sendMessage("Order status changed", "Order #" . $order_id . " is on hold", ['order_id' => $order_id], [$order_meta['player_id'][0]]);
    }
}
function myorder_processing($order_id) {
    $order_meta = get_post_meta($order_id);
    if(isset($order_meta['player_id']) && isset($order_meta['player_id'][0])){
        sendMessage("Order status changed", "Order #" . $order_id . " is being processed", ['order_id' => $order_id], [$order_meta['player_id'][0]]);
    }
}
function myorder_completed($order_id) {
    $order_meta = get_post_meta($order_id);
    if(isset($order_meta['player_id']) && isset($order_meta['player_id'][0])){
        sendMessage("Order status changed", "Order #" . $order_id . " is marked completed", ['order_id' => $order_id], [$order_meta['player_id'][0]]);
    }
}
function myorder_refunded($order_id) {
    $order_meta = get_post_meta($order_id);
    if(isset($order_meta['player_id']) && isset($order_meta['player_id'][0])){
        sendMessage("Order status changed", "Order #" . $order_id . " is marked refunded", ['order_id' => $order_id], [$order_meta['player_id'][0]]);
    }
}
function myorder_cancelled($order_id) {
    $order_meta = get_post_meta($order_id);
    if(isset($order_meta['player_id']) && isset($order_meta['player_id'][0])){
        sendMessage("Order status changed", "Order #" . $order_id . " is marked cancelled", ['order_id' => $order_id], [$order_meta['player_id'][0]]);
    }
}
function create_invoice_for_wc_order($order_id) { 
    $order_meta = get_post_meta($order_id);
    if(isset($order_meta['player_id']) && isset($order_meta['player_id'][0])){
        sendMessage("Order #" . $order_id . " has been created", "Thank you for shopping with us.", ['order_id' => $order_id], [$order_meta['player_id'][0]]);
    }
}; 

add_action( 'woocommerce_order_status_pending', 'myorder_pending');
add_action( 'woocommerce_order_status_failed', 'myorder_failed');
add_action( 'woocommerce_order_status_on-hold', 'myorder_hold');
// Note that it's woocommerce_order_status_on-hold, not on_hold.
add_action( 'woocommerce_order_status_processing', 'myorder_processing');
add_action( 'woocommerce_order_status_completed', 'myorder_completed');
add_action( 'woocommerce_order_status_refunded', 'myorder_refunded');
add_action( 'woocommerce_order_status_cancelled', 'myorder_cancelled');

add_action( 'woocommerce_new_order', 'create_invoice_for_wc_order');


/* register menu item */
function solosignal_admin_menu_setup(){
    add_submenu_page(
        'options-general.php',
        'Solosignal Settings',
        'Solosignal',
        'manage_options',
        'solosignal',
        'solosignal_admin_page_screen'
    );
}
add_action('admin_menu', 'solosignal_admin_menu_setup');
    
/* display page content */
function solosignal_admin_page_screen() {
    global $submenu;
    // access page settings 
    $page_data = array();
    foreach($submenu['options-general.php'] as $i => $menu_item) {
        if($submenu['options-general.php'][$i][2] == 'solosignal')
        $page_data = $submenu['options-general.php'][$i];
    }
    ?>

    <div class="wrap">
        <?php screen_icon();?>
        <h2><?php echo $page_data[3];?></h2>
        <form id="solosignal_options" action="options.php" method="post">
            <?php
            settings_fields('solosignal_options');
            do_settings_sections('solosignal'); 
            submit_button('Save Changes', 'primary', 'solosignal_options_submit');
            ?>
        </form>
    </div>
    <?php
}
/* settings link in plugin management screen */
function solosignal_settings_link($actions, $file = '') {
    if(false !== strpos($file, 'msp-solosignal'))
     $actions['settings'] = '<a href="options-general.php?page=solosignal">Settings</a>';
    return $actions; 
}
add_filter('plugin_action_links', 'solosignal_settings_link');

/* register settings */
function solosignal_settings_init(){
    register_setting(
     'solosignal_options',
     'solosignal_options',
     'solosignal_options_validate'
    );
    
    add_settings_section(
     'solosignal_onesignal_settings',
     'Onesignal Settings', 
     'solosignal_onesignal_settings_desc',
     'solosignal'
    );
    
    add_settings_field(
     'solosignal_onesignal_app_id',
     'Onesignal App ID', 
     'solosignal_onesignal_settings_field',
     'solosignal',
     'solosignal_onesignal_settings'
    );

    add_settings_field(
     'solosignal_onesignal_api_key',
     'Rest API Key', 
     'solosignal_onesignal_settings_api_key_field',
     'solosignal',
     'solosignal_onesignal_settings'
    );
}
    
add_action('admin_init', 'solosignal_settings_init');
    
/* validate input */
function solosignal_options_validate($input){
    global $allowedposttags, $allowedrichhtml;
    if(isset($input['onesignal_app_id']) && isset($input['onesignal_api_key']))
        $input['onesignal_app_id'] = wp_kses_post($input['onesignal_app_id']);
        $input['onesignal_api_key'] = wp_kses_post($input['onesignal_api_key']);
        return $input;
}
    
/* description text */
function solosignal_onesignal_settings_desc(){
    echo "<p>Enter the credentials you got from Onesignal.</p>";
}
    
/* filed output */
function solosignal_onesignal_settings_field() {
     $options = get_option('solosignal_options');
     $myAppID = (isset($options['onesignal_app_id'])) ? $options['onesignal_app_id'] : '';
     $myAppID = esc_textarea($myAppID); //sanitise output
    ?>
        <input type="text" id="onesignal_app_id" name="solosignal_options[onesignal_app_id]" class="regular-text" value="<?php echo $myAppID;?>" autocomplete="app-id" required>
    <?php
}

function solosignal_onesignal_settings_api_key_field() {
    $options = get_option('solosignal_options');
    $myApiKey = (isset($options['onesignal_api_key'])) ? $options['onesignal_api_key'] : '';
    $myApiKey = esc_textarea($myApiKey); //sanitise output
   ?>
       <input type="text" id="onesignal_api_key" name="solosignal_options[onesignal_api_key]" class="regular-text" value="<?php echo $myApiKey;?>" autocomplete="api-key" required>
   <?php
}